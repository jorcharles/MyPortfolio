namespace LibraSys.Api.Configuration;

public sealed class DatabaseOptions
{
    public const string SectionName = "Database";
    public string ConnectionString { get; set; } = string.Empty;
    public string EncryptionKey { get; set; } = string.Empty;
}
